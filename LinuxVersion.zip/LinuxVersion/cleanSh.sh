rm -rf *.h.gch
echo "Clean all success!\n"
