#pragma once
#include "json/json.h"
#include <algorithm> // sort
#include <sstream>
#include <string.h>
#include <iostream>

class CParseJson;

struct Options
{
	std::string path;
	Json::Features features;
	bool parseOnly;
	typedef std::string(CParseJson::*writeFuncType)(Json::Value const&);
	writeFuncType write;
};

class CParseJson
{
public:
	CParseJson();
	~CParseJson();
private:
	
public:
	std::string parseString(const std::string& input,
	Json::Value* root,
	std::string type);
	int getJsonValue(const std::string& input,
		Json::Value* root);
};

